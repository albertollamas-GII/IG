#ifndef _ESCENA_H
#define _ESCENA_H

#include "ejes.h"
#include "malla.h"
#include "cubo.h"
#include "tetraedro.h"
#include "objrevolucion.h"
#include "objply.h"
#include "cilindro.h"
#include "cono.h"
#include "esfera.h"
#include "luz.h"
#include "luzPosicional.h"
#include "luzDireccional.h"
#include "material.h"

typedef enum
{
    NADA,
    SELOBJETO,
    SELVISUALIZACION,
    SELDIBUJADO,
    SELILUMINACION
} menu;

typedef enum
{
    TETRAEDRO,
    CUBO,
    NINGUNO
} objetoActivo;


class Escena
{

private:
    // ** PARÁMETROS DE LA CÁMARA (PROVISIONAL)

    // variables que definen la posicion de la camara en coordenadas polares
    GLfloat Observer_distance;
    GLfloat Observer_angle_x;
    GLfloat Observer_angle_y;

    // variables que controlan la ventana y la transformacion de perspectiva
    GLfloat Width, Height, Front_plane, Back_plane;

    // Transformación de cámara
    void change_projection(const float ratio_xy);
    void change_observer();

    void clear_window();

    menu modoMenu = NADA;
    objetoActivo objeto = NINGUNO;
    modoDibujado modo = INMEDIATO;
    std::vector<bool> visu; 
    
    bool modo_solido = true;
    bool modo_puntos = false;
    bool modo_lineas = false;
    bool modo_ajedrez = false;

    bool Bcubo = true;
    bool Btetraedro = true;
    bool Bcilindro = true;
    bool Bcono = true;
    bool Besfera = true;
    bool Bply = true;
    bool Brev = true;

    bool tapa_sup = true, tapa_inf = true, tapas = true;
    // Objetos de la escena
    Ejes ejes;
    Cubo *cubo = nullptr;           // es importante inicializarlo a 'nullptr'
    Tetraedro *tetraedro = nullptr; // es importante inicializarlo a 'nullptr'
    ObjRevolucion *peon = nullptr;
    Cilindro *cilindro = nullptr;
    Cono *cono = nullptr;
    Esfera *esfera = nullptr;
    ObjPLY *beethoven = nullptr;
    LuzPosicional * luz0 = nullptr;
    LuzDireccional * luz1 = nullptr;
    Luz * luz2 = nullptr;
    Luz * luz3 = nullptr;
    Luz * luz4 = nullptr;
    Luz * luz5 = nullptr;
    Luz * luz6 = nullptr;
    Luz * luz7 = nullptr;

    ObjRevolucion *peon_blanco = nullptr;
    ObjRevolucion *peon_negro = nullptr;
    bool Bpeon_blanco = true;
    bool Bpeon_negro = true;

    std::vector<bool> luz_activada;
    char angulo;

public:
    Escena();
    void inicializar(int UI_window_width, int UI_window_height);
    void redimensionar(int newWidth, int newHeight);

    // Dibujar
    void dibujar();

    // Interacción con la escena
    bool teclaPulsada(unsigned char Tecla1, int x, int y);
    void teclaEspecial(int Tecla1, int x, int y);
};
#endif
