

#include "aux.h" // includes de OpenGL/glut/glew, windows, y librería std de C++
#include "escena.h"
#include "malla.h" // objetos: Cubo y otros....
#include "objrevolucion.h"

//**************************************************************************
// constructor de la escena (no puede usar ordenes de OpenGL)
//**************************************************************************
Escena::Escena()
{
   Front_plane = 50.0;
   Back_plane = 2000.0;
   Observer_distance = 4 * Front_plane;
   Observer_angle_x = 0.0;
   Observer_angle_y = 0.0;

   ejes.changeAxisSize(5000);

   // crear los objetos de la escena....
   // .......completar: ...
   // .....
   visu.resize(5);
   for (int i = 0; i < visu.size(); i++)
      visu[i] = false;
   visu[4] = true;

   luz_activada.resize(8);
   for (int i = 0; i < luz_activada.size(); i++)
      luz_activada[i] = false;
   luz_activada[0] = true;

   luz0 = new LuzPosicional(Tupla3f(0, 0, 90), GL_LIGHT0, Tupla4f(1, 1, 1, 1), Tupla4f(1, 1, 1, 0.5), Tupla4f(1, 1, 1, 1));
   luz1 = new LuzDireccional(Tupla2f(0, 0), GL_LIGHT1, Tupla4f(1, 1, 1, 1), Tupla4f(1, 1, 1, 1), Tupla4f(1, 1, 1, 1));
   
   cubo = new Cubo(20);
   tetraedro = new Tetraedro(20);
   lata = new ObjRevolucion("plys/lata-pcue.ply", 10, tapa_sup, tapa_inf, 'y');
   cono = new Cono(10, 10, 70, 30, tapa_sup, tapa_inf);
   cilindro = new Cilindro(100, 100, 70, 30, tapa_sup, tapa_inf);
   esfera = new Esfera(100, 100, 30, tapa_sup, tapa_inf);
   beethoven = new ObjPLY("plys/beethoven.ply");
   sol = new Esfera(100,100,10);


   Material comun(Tupla4f(0.07, 0.6, 0.07, 1), Tupla4f(0.6, 0.7, 0.6, 1), Tupla4f(0.02, 0.1, 0.02, 1), 1);
   Material grey(Tupla4f(0.01,0.01,0.01,0.2),Tupla4f(0.5,0.5,0.5,1),Tupla4f(0,0,0,1),1);
   Material white(Tupla4f(0.55, 0.55, 0.55, 1), Tupla4f(0, 0, 0, 0), Tupla4f(1, 1, 1, 1), 1);

   cubo->setMaterial(comun);
   tetraedro->setMaterial(comun);
   lata->setMaterial(grey);
   cono->setMaterial(comun);
   cilindro->setMaterial(comun);
   esfera->setMaterial(comun);
   beethoven->setMaterial(white);
   sol->setMaterial(comun);

   satelite = new Satelite();
   angulo_giro = 0;
}

//**************************************************************************
// inicialización de la escena (se ejecuta cuando ya se ha creado la ventana, por
// tanto sí puede ejecutar ordenes de OpenGL)
// Principalmemnte, inicializa OpenGL y la transf. de vista y proyección
//**************************************************************************

void Escena::inicializar(int UI_window_width, int UI_window_height)
{
   glClearColor(1.0, 1.0, 1.0, 1.0); // se indica cual sera el color para limpiar la ventana	(r,v,a,al)

   glEnable(GL_DEPTH_TEST); // se habilita el z-bufer

   Width = UI_window_width / 10;
   Height = UI_window_height / 10;

   change_projection(float(UI_window_width) / float(UI_window_height));
   glViewport(0, 0, UI_window_width, UI_window_height);
}

// **************************************************************************
//
// función de dibujo de la escena: limpia ventana, fija cámara, dibuja ejes,
// y dibuja los objetos
//
// **************************************************************************

//colocar cada objeto en un sitio distinto
void Escena::dibujar()
{

   glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); // Limpiar la pantalla
   change_observer();

   glDisable(GL_LIGHTING);

   ejes.draw();

   if (visu[4])
   {
      glEnable(GL_LIGHTING);
   }
   else
   {
      glDisable(GL_LIGHTING);
   }

   glPushMatrix();
         glRotatef(angulo_giro,0,1,0);
         if(luz_activada[0]){
            luz0->activar();
            glTranslatef(0,45,90);
            sol->draw(modo,visu,tapas);
         } else{
            luz0->desactivar();
         }
   glPopMatrix();

   glPushMatrix();
      if (luz_activada[1])
         luz1->activar();
      else
         luz1->desactivar();
   glPopMatrix();

   glPushMatrix();
      glTranslatef(0, 0, -100);
      cubo->draw(modo, visu, true);
   glPopMatrix();

   glPushMatrix();
      glTranslatef(0, 0, 100);
      tetraedro->draw(modo, visu,true);
   glPopMatrix();

   glPushMatrix();
      glTranslatef(-100, 0, 0);
      glScalef(30, 30, 30);
      lata->draw(modo, visu, tapas);
   glPopMatrix();
   
   glPushMatrix();
      glTranslatef(-70, 0, 100);
      cilindro->draw(modo, visu, tapas);
   glPopMatrix();

   glPushMatrix();
      glTranslatef(-100, 0, -100);
      cono->draw(modo, visu, tapas);
   glPopMatrix();

   glPushMatrix();
      glTranslatef(100, 0, 100);
      esfera->draw(modo, visu, tapas);
   glPopMatrix();

   glPushMatrix();
      glTranslatef(100, 0, -100);
      glScalef(10, 10, 10);
      beethoven->draw(modo, visu, true);
   glPopMatrix();


   glPushMatrix();
      glScalef(0.5,0.5,0.5);
      satelite->draw(modo,visu,tapas);
   glPopMatrix();

}

//**************************************************************************
//
// función que se invoca cuando se pulsa una tecla
// Devuelve true si se ha pulsado la tecla para terminar el programa (Q),
// devuelve false en otro caso.
//
//**************************************************************************

bool Escena::teclaPulsada(unsigned char tecla, int x, int y)
{
   using namespace std;
   cout << "Tecla pulsada: '" << tecla << "'" << endl;
   bool salir = false;
   switch (toupper(tecla))
   {
   case 'Q':
      if (modoMenu != NADA)
         modoMenu = NADA;
      else
      {
         salir = true;
      }
      break;
   case 'H':
         if (tapas)
         {
            cout << "\nQuitando Tapas" << endl;
            tapas = false;
         }
         else
         {
            cout << "\nPoniendo Tapas" << endl;
            tapas = true;
         }
      break;

   case 'O':
      // ENTRAMOS EN MODO SELECCION DE OBJETO
      if (modoMenu == NADA)
      {
         
         modoMenu = SELOBJETO;
      }
      else
      {
         cout << "Opcion no valida!\n";
      }
      break;

   case 'V':
      // ENTRAMOS EN MODO SELECCION DE MODO DE VISUALIZACION
      if (modoMenu == NADA)
      {
         cout << "Menu seleccion de modo de visualizacion" << endl;
         cout << "Activar/desactivar visualización en modo puntos: P" << endl;
         cout << "Activar/desactivar visualización en modo lineas: L" << endl;
         cout << "Activar/desactivar visualización en modo solido: S" << endl;
         cout << "Activar/desactivar visualización en modo ajedrez: A" << endl;
         cout << "Activar/desactivar visualización en modo iluminacion: I" << endl;

         modoMenu = SELVISUALIZACION;
      }
      else
      {
         cout << "Opcion no valida!\n";
      }

   case 'D':
      // ENTRAMOS EN MODO SELECCION DE DIBUJADO
      if (modoMenu == NADA)
      {
         cout << "Menu seleccion de modo de dibujado" << endl;
         cout << "1: Activar dibujado con glDrawElements" << endl;
         cout << "2: Activar dibujado con Vertex Buffer Objects" << endl;
         modoMenu = SELDIBUJADO;
      }
      else
      {
         cout << "Opcion no valida!\n";
      }
      break;

   //MODO SELECCION OBJETO

   //MODO SELECCION MODO DE VISUALIZACION
   case 'P':
      if (modoMenu == SELVISUALIZACION)
      {
         if (visu[0])
         {
            visu[0] = false;
         }
         else
         {
            cout << "Modo Puntos elegido\n";
            visu[4] = false;
            visu[0] = true;
         }
      }
      else
         cout << "Opcion no valida!\n";
      break;

   case 'L':
      if (modoMenu == SELVISUALIZACION)
      {
         if (visu[1])
            visu[1] = false;
         else
         {
            cout << "Modo Lineas elegido\n";
            visu[4] = false;
            visu[1] = true;
         }
      }
      else
         cout << "Opcion no valida!\n";
      break;

   case 'S':
      if (modoMenu == SELVISUALIZACION)
      {
         if (visu[2])
            visu[2] = false;
         else
         {
            cout << "Modo Solido elegido\n";
            visu[4] = false;
            visu[2] = true;
         }
      }
      else
         cout << "Opcion no valida!\n";

      break;

   case 'A':
      if (modoMenu == SELVISUALIZACION)
      {
         if (visu[3])
            visu[3] = false;
         else
         {
            cout << "Modo Ajedrez elegido\n";
            visu[4] = false;
            visu[3] = true;
         }
      }
      else if (modoMenu == SELILUMINACION)
      {
         if (luz_activada[1])
         {
            angulo = 'a';
            cout << "Ángulo alfa elegido.\n";
         }
      } 
      else
         cout << "Opcion no valida!\n";
      
      if (animacion){
         cout << "Desactivando animacion automatica.\n";
         animacion = false;
      } else{
         cout << "Activando animacion automatica.\n";
         animacion = true;
      }
      break;
   case 'I':
      if (modoMenu == SELVISUALIZACION)
      {
         if (!visu[4])
         {
            cout << "Modo Iluminacion elegido\n";
            cout << "Usa las teclas 0 a 7 para activar las diferentes luces de la escena.\n";
            cout << "Las teclas 0 y 1 son para la luz posicional y direccional respectivamente.\n";
            cout << "A: activar modo variación ángulo alfa.\n";
            cout << "B: activar modo variacion ángulo beta.\n";
            cout << "Usa > y < para incrementar y decrementar respectivamente el ángulo elegido anteriormente.\n";
            visu[4] = true;
            for (int i = 0; i < 4; i++)
               visu[i] = false;

            modoMenu = SELILUMINACION;
         }
      }
      else
         cout << "Opcion no valida!\n";
      break;
      //MODO SELECCION DE DIBUJADO
   case '0':
      grado_de_libertad = '0';
      if (modoMenu == SELILUMINACION)
      {
         if (!luz_activada[0] && luz0 != nullptr)
         {
            cout << "Luz Posicional activada\n";
            luz_activada[0] = true;
         }
         else
         {
            luz_activada[0] = false;
            cout << "Luz Posicional desactivada.\n";
         }
      }
      else
         cout << "Opcion no valida!\n";
      break;

   case '1':
      grado_de_libertad = '1';
      if (modoMenu == SELDIBUJADO)
      {
         cout << "Modo Inmediato elegido\n";
         modo = INMEDIATO;
      }
      else if (modoMenu == SELILUMINACION)
      {
         if (!luz_activada[1] && luz1 != nullptr)
         {
            cout << "Luz Direccional activada\n";
            luz_activada[1] = true;
         }
         else
         {
            luz_activada[1] = false;
            cout << "Luz Direccional desactivada.\n";
         }
      }
      else
         cout << "Opcion no valida!\n";
      break;

   case '2':
      grado_de_libertad = '2';
      if (modoMenu == SELDIBUJADO)
      {
         cout << "Modo Diferido elegido\n";
         modo = DIFERIDO;
      }
      else if (modoMenu == SELILUMINACION)
      {
         if (!luz_activada[2] && luz2 != nullptr)
         {
            cout << "Luz 2 activada\n";
            luz_activada[2] = true;
         }
         else
         {
            luz_activada[2] = false;
            cout << "Luz 2 desactivada.\n";
         }
      }
      else
         cout << "Opcion no valida!\n";
      break;

   //MODO SELECCION DE ILUMINACION
   case '3':
      grado_de_libertad = '3';
      if (modoMenu == SELILUMINACION)
      {
         if (!luz_activada[3] && luz3 != nullptr)
         {
            cout << "Luz 3 activada\n";
            luz_activada[3] = true;
         }
         else
         {
            luz_activada[3] = false;
            cout << "Luz 3 desactivada.\n";
         }
      }
      else
         cout << "Opcion no valida!\n";
      break;
   case '4':
      if (modoMenu == SELILUMINACION)
      {
         if (!luz_activada[4] && luz4 != nullptr)
         {
            cout << "Luz 4 activada\n";
            luz_activada[4] = true;
         }
         else
         {
            luz_activada[4] = false;
            cout << "Luz 4 desactivada.\n";
         }
      }
      else
         cout << "Opcion no valida!\n";
      break;
   case '5':
      if (modoMenu == SELILUMINACION)
      {
         if (!luz_activada[5] && luz5 != nullptr)
         {
            cout << "Luz 5 activada\n";
            luz_activada[5] = true;
         }
         else
         {
            luz_activada[5] = false;
            cout << "Luz 5 desactivada.\n";
         }
      }
      else
         cout << "Opcion no valida!\n";
      break;
   case '6':
      if (modoMenu == SELILUMINACION)
      {
         if (!luz_activada[6] && luz6 != nullptr)
         {
            cout << "Luz 6 activada\n";
            luz_activada[6] = true;
         }
         else
         {
            luz_activada[6] = false;
            cout << "Luz 6 desactivada.\n";
         }
      }
      else
         cout << "Opcion no valida!\n";
      break;
   case '7':
      if (modoMenu == SELILUMINACION)
      {
         if (!luz_activada[7] && luz7 != nullptr)
         {
            cout << "Luz 7 activada\n";
            luz_activada[7] = true;
         }
         else
         {
            luz_activada[7] = false;
            cout << "Luz 7 desactivada.\n";
         }
      }
      else
         cout << "Opcion no valida!\n";
      break;
   case 'B':
      if (modoMenu == SELILUMINACION)
      {
         if (luz_activada[1])
         {
            angulo = 'b';
            cout << "Ángulo beta elegido.\n";
         }
      }
      else
      {
         cout << "Opción no valida.\n";
      }
      break;
   case '<':
      if (modoMenu == SELILUMINACION)
      {
         if (angulo == 'a')
         {
            luz1->variarAnguloAlpha(-10);
            cout << "Variado ángulo alfa.\n";
         }

         else if (angulo == 'b')
         {
            luz1->variarAnguloBeta(-10);
            cout << "Variado ángulo beta.\n";
         }

         else
            cout << "No has elegido un ángulo para variar" << endl;
      }
      break;
   case '>':
      if (modoMenu == SELILUMINACION)
      {
         if (angulo == 'a')
         {
            luz1->variarAnguloAlpha(10);
            cout << "Variado ángulo alfa.\n";
         }

         else if (angulo == 'b')
         {
            luz1->variarAnguloBeta(10);
            cout << "Variado ángulo beta.\n";
         }

         else
            cout << "No has elegido un ángulo para variar" << endl;
      }
      break;

      case 'M':
         if (modoMenu == NADA){
            modoMenu = MANIPULACION;
            animacion = false;
            satelite->setManual(true);
            cout << "Menu selección grado de libertad a modificar\n";
            cout << "Tecla 0: giro alpha de la antena\n";
            cout << "Tecla 1: giro beta de la antena\n";
            cout << "Tecla 2: Translacion de la nave alienigena sobre el panel\n";
            cout << "Tecla 3: Rotacion Satelite\n";

         } else{
            cout << "Opcion no valida!\n";
         }
      break;

      case '+':
         if (modoMenu == MANIPULACION){
            switch(grado_de_libertad){
               case '0':
                  satelite->aumentar_alpha();
               break;

               case '1':
                  satelite->aumentar_beta();
               break;

               case '2':
                  satelite->aumentar_x_nave();
               break;
               case '3':
                  satelite->girar();
               break;
               default:
               break;
            }
         }
      break;

      case '-':
         if (modoMenu == MANIPULACION){
            switch(grado_de_libertad){
               case '0':
                  satelite->reducir_alpha();
               break;

               case '1':
                  satelite->reducir_beta();
               break;

               case '2':
                  satelite->reducir_x_nave();
               break;
               case '3':
                  satelite->reducir_giro();
               break;
               default:
               break;
            }
         }
      break;
      
   }
   return salir;
}
//**************************************************************************

void Escena::teclaEspecial(int Tecla1, int x, int y)
{
   switch (Tecla1)
   {
   case GLUT_KEY_LEFT:
      Observer_angle_y--;
      break;
   case GLUT_KEY_RIGHT:
      Observer_angle_y++;
      break;
   case GLUT_KEY_UP:
      Observer_angle_x--;
      break;
   case GLUT_KEY_DOWN:
      Observer_angle_x++;
      break;
   case GLUT_KEY_F1: //He cambiado las teclas porque no las tengo en mi teclado
      Observer_distance *= 1.2;
      break;
   case GLUT_KEY_F2: // He cambiado las teclas porque no las tengo en mi teclado
      Observer_distance /= 1.2;
      break;
   }

   //std::cout << Observer_distance << std::endl;
}

//**************************************************************************
// Funcion para definir la transformación de proyeccion
//
// ratio_xy : relacción de aspecto del viewport ( == ancho(X) / alto(Y) )
//
//***************************************************************************

void Escena::change_projection(const float ratio_xy)
{
   glMatrixMode(GL_PROJECTION);
   glLoadIdentity();
   const float wx = float(Height) * ratio_xy;
   glFrustum(-wx, wx, -Height, Height, Front_plane, Back_plane);
}
//**************************************************************************
// Funcion que se invoca cuando cambia el tamaño de la ventana
//***************************************************************************

void Escena::redimensionar(int newWidth, int newHeight)
{
   Width = newWidth / 10;
   Height = newHeight / 10;
   change_projection(float(newHeight) / float(newWidth));
   glViewport(0, 0, newWidth, newHeight);
}

//**************************************************************************
// Funcion para definir la transformación de vista (posicionar la camara)
//***************************************************************************

void Escena::change_observer()
{
   // posicion del observador
   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();
   glTranslatef(0.0, 0.0, -Observer_distance);
   glRotatef(Observer_angle_y, 0.0, 1.0, 0.0);
   glRotatef(Observer_angle_x, 1.0, 0.0, 0.0);
}

void Escena::animarModeloJerarquico(){
   if(animacion)
      satelite->animacion();

   angulo_giro+=0.01;
}