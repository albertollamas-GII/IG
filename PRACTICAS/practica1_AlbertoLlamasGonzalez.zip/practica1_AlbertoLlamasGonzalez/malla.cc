#include "aux.h"
#include "malla.h"
// Funciones de OpenGL solo en funciones draw NO en constructores
//  *****************************************************************************
//
//  Clase Malla3D
//
//  *****************************************************************************
/**
 *
 * */

// -----------------------------------------------------------------------------
// Visualización en modo diferido con 'glDrawElements' (usando VBOs)
GLuint Malla3D::CrearVBO(GLuint tipo_vbo, GLuint tamanio_bytes, GLvoid *puntero_ram)
{
   GLuint id_vbo;
   glGenBuffers(1, &id_vbo);
   glBindBuffer(tipo_vbo, id_vbo);
   glBufferData(tipo_vbo, tamanio_bytes, puntero_ram, GL_STATIC_DRAW);
   glBindBuffer(tipo_vbo, 0);
   return id_vbo;
}

// Visualización en modo inmediato con 'glDrawElements'
void Malla3D::cargarColor(std::vector<Tupla3f> &c, Tupla3f color){
   for (int i = 0; i < v.size(); i++)
      c.push_back(color);
}
void Malla3D::draw_ModoInmediato(visualizacion visu)
{
   // visualizar la malla usando glDrawElements,
   // completar (práctica 1)

   // habilitar uso de un array de vértices
   glEnableClientState(GL_VERTEX_ARRAY);
   glEnableClientState(GL_COLOR_ARRAY);

   // indicar el formato y la dirección de memoria del array de vértices
   // (son tuplas de 3 valores float, sin espacio entre ellas)
   glVertexPointer(3, GL_FLOAT, 0, v.data());

   if (visu == BLANCO)
   {}

   if (visu == PUNTOS)
   {
      glEnable(GL_CULL_FACE);                     //deshabilitamos cull_face para ver las lineas traseras
      glPolygonMode(GL_FRONT_AND_BACK, GL_POINT); //Usamos GL_POINT para pintar los puntos
      glPointSize(3);                             //Inndicar tamaño de los puntos
      Tupla3f color (0,1,0);
      cargarColor(c_puntos, color);
      if (c_puntos.size() != 0)
         glColorPointer(3, GL_FLOAT, 0, c_puntos.data());
      else
         glDisableClientState(GL_COLOR_ARRAY);
      //visualizar, indicando: tipo de primitiva, número de indices
      //tipo de los indices, y direccion de la tabla de vertices.
      glDrawElements(GL_TRIANGLES, f.size() * 3, GL_UNSIGNED_INT, f.data());
   }

   if (visu == LINEAS)
   {
      glEnable(GL_CULL_FACE);
      glPolygonMode(GL_FRONT_AND_BACK, GL_LINE); //usamos GL_LINE para pintar las lineas
      glLineWidth(1);                            //Indicar tamaño de linea
      Tupla3f color (0,0,1);
      cargarColor(c_lineas, color);
      if (c_lineas.size() != 0)
         glColorPointer(3, GL_FLOAT, 0, c_lineas.data());
      else
         glDisableClientState(GL_COLOR_ARRAY);

      glDrawElements(GL_TRIANGLES, f.size() * 3, GL_UNSIGNED_INT, f.data());
   }

   if (visu == SOLIDO)
   {
      glEnable(GL_CULL_FACE); //habilitamos cull_face para no ver las caras de atras
      glPolygonMode(GL_FRONT, GL_FILL);

      Tupla3f color (1,0,0);
      cargarColor(c_solido, color);
      //dependiendo del array de colores, habilitamos o deshabilitamos el array
      if (c_solido.size() != 0)
         glColorPointer(3, GL_FLOAT, 0, c_solido.data());
      else
         glDisableClientState(GL_COLOR_ARRAY);

      glDrawElements(GL_TRIANGLES, f.size() * 3, GL_UNSIGNED_INT, f.data());
   }
   else if (visu == AJEDREZ){
      dividirTriangulosAjedrez();
      drawAjedrez(INMEDIATO);
   }

   //deshabilitar array de vertices
   glDisableClientState(GL_VERTEX_ARRAY);
   glDisableClientState(GL_COLOR_ARRAY);
}

void Malla3D::draw_ModoDiferido(visualizacion visu)
{
   // (la primera vez, se deben crear los VBOs y guardar sus identificadores en el objeto)
   // completar (práctica 1)

   // // Comprobamos si estan creados los VBO's
   if (id_vbo_ver == 0)
      id_vbo_ver = CrearVBO(GL_ARRAY_BUFFER, v.size() * 3 * sizeof(float), v.data());
   if (id_vbo_tri == 0)
      id_vbo_tri = CrearVBO(GL_ELEMENT_ARRAY_BUFFER, f.size() * 3 * sizeof(float), f.data());

   glBindBuffer(GL_ARRAY_BUFFER, id_vbo_ver); // activar VBO de vértices
   glVertexPointer(3, GL_FLOAT, 0, 0);        // especifica formato y offset(=0)
   glBindBuffer(GL_ARRAY_BUFFER, 0);          // desactivar VBO de vértices
   glEnableClientState(GL_VERTEX_ARRAY);      // habilitar tabla de vertices

   // visualizar triángulos con glDrawElements (puntero a tabla == 0)

   glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, id_vbo_tri); // activar VBO de triángulos

   if (visu == BLANCO)
   {
   }

   if (visu == LINEAS)
   {
      Tupla3f color (0,0,1);
      cargarColor(c_lineas, color);
      crearColorDiferido(id_vbo_col_lin, c_lineas);
      glEnable(GL_CULL_FACE);
      glLineWidth(1);
      glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
      glDrawElements(GL_TRIANGLES, f.size() * 3, GL_UNSIGNED_INT, 0);
   }

   if (visu == PUNTOS)
   {
      Tupla3f color (0,1,0);
      cargarColor(c_puntos, color);
      crearColorDiferido(id_vbo_col_pun, c_puntos);
      glEnable(GL_CULL_FACE);
      glPolygonMode(GL_FRONT_AND_BACK, GL_POINT);
      glPointSize(3);
      glDrawElements(GL_TRIANGLES, f.size() * 3, GL_UNSIGNED_INT, 0);
   }

   if (visu == SOLIDO)
   {
      Tupla3f color (1,0,0);
      cargarColor(c_solido, color);
      crearColorDiferido(id_vbo_col_sol, c_solido);
      glEnable(GL_CULL_FACE);
      glPolygonMode(GL_FRONT, GL_FILL);
      glDrawElements(GL_TRIANGLES, f.size() * 3, GL_UNSIGNED_INT, 0);
   }
   else if (visu == AJEDREZ)
   {
      dividirTriangulosAjedrez();
      if (id_vbo_ajedrez_par == 0)
         id_vbo_ajedrez_par = CrearVBO(GL_ELEMENT_ARRAY_BUFFER, f_ajedrez_par.size() * 3 * sizeof(float), f_ajedrez_par.data());
      if (id_vbo_ajedrez_impar == 0)
         id_vbo_ajedrez_impar = CrearVBO(GL_ELEMENT_ARRAY_BUFFER, f_ajedrez_impar.size() * 3 * sizeof(float), f_ajedrez_impar.data());
      drawAjedrez(DIFERIDO);
   }

   glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0); //desactivar VBO de triangulos
   glDisableClientState(GL_VERTEX_ARRAY); // desactivar uso de array de vertices
   glDisableClientState(GL_COLOR_ARRAY);
}

void Malla3D::crearColorDiferido(GLuint &id_vbo_col, std::vector<Tupla3f> c){
      if (c.size() != 0 || id_vbo_col == 0)
      {
         id_vbo_col = CrearVBO(GL_ARRAY_BUFFER, c.size() * 3 * sizeof(float), c.data());
         
      }
      // Cargamos los colores
      glEnableClientState(GL_COLOR_ARRAY);           // habilitar tabla de colores
      glBindBuffer(GL_ARRAY_BUFFER, id_vbo_col); // activar VBO de colores
      glColorPointer(3, GL_FLOAT, 0, 0);             // formato y offset (=0)
      glBindBuffer(GL_ARRAY_BUFFER, 0);              // desactivar VBO de colores
}

//Metodo para dividir las caras del modo ajedrez
void Malla3D::dividirTriangulosAjedrez()
{
   for (int i = 0; i < f.size(); i += 2)
   {
      f_ajedrez_par.push_back(f[i]);
   }

   for (int i = 1; i < f.size(); i += 2)
   {
      f_ajedrez_impar.push_back(f[i]);
   }
}

//metodo para dibujar en modo ajedrez
void Malla3D::drawAjedrez(modoDibujado modo)
{
   if (modo == DIFERIDO)
   {
      glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, id_vbo_ajedrez_par); // activar VBO de cada grupo de triangulos
      Tupla3f color (0,0,0);
      cargarColor(c_ajedrez_par, color);
      crearColorDiferido(id_vbo_col_ajedrez_par, c_ajedrez_par);
      glEnable(GL_CULL_FACE);
      glPolygonMode(GL_FRONT, GL_FILL);
      glDrawElements(GL_TRIANGLES, f_ajedrez_par.size() * 3, GL_UNSIGNED_INT, 0);

      glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, id_vbo_ajedrez_impar); // activar VBO de cada grupo de triangulos
      Tupla3f color2 (1,0,0);
      cargarColor(c_ajedrez_impar, color2);
      crearColorDiferido(id_vbo_col_ajedrez_impar, c_ajedrez_impar);
      glEnable(GL_CULL_FACE);
      glPolygonMode(GL_FRONT, GL_FILL);
      glDrawElements(GL_TRIANGLES, f_ajedrez_impar.size() * 3, GL_UNSIGNED_INT, 0);   
   }
   else if (modo == INMEDIATO)
   {

      glEnable(GL_CULL_FACE);
      glPolygonMode(GL_FRONT, GL_FILL);
      glShadeModel(GL_FLAT);
      Tupla3f color (0,0,0);
      cargarColor(c_ajedrez_par, color);
      // Pintamos triangulos pares
      if (c_ajedrez_par.size() != 0)
         glColorPointer(3, GL_FLOAT, 0, c_ajedrez_par.data());

      glDrawElements(GL_TRIANGLES, f_ajedrez_par.size() * 3, GL_UNSIGNED_INT, f_ajedrez_par.data());

      Tupla3f color2 (1,0,0);
      cargarColor(c_ajedrez_impar, color2);
      // Pintamos triangulos impares
      if (c_ajedrez_impar.size() != 0)
         glColorPointer(3, GL_FLOAT, 0, c_ajedrez_impar.data());

      glDrawElements(GL_TRIANGLES, f_ajedrez_impar.size() * 3, GL_UNSIGNED_INT, f_ajedrez_impar.data());
   }
}

// -----------------------------------------------------------------------------
// Función de visualización de la malla,
// puede llamar a  draw_ModoInmediato o bien a draw_ModoDiferido

void Malla3D::draw(modoDibujado modo, visualizacion visu)
{
   if (modo == INMEDIATO)
      draw_ModoInmediato(visu);
   else if (modo == DIFERIDO)
      draw_ModoDiferido(visu);
   else if (visu == AJEDREZ)
      drawAjedrez(modo);
}
