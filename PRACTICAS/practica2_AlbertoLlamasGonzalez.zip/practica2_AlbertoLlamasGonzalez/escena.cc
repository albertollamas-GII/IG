

#include "aux.h" // includes de OpenGL/glut/glew, windows, y librería std de C++
#include "escena.h"
#include "malla.h" // objetos: Cubo y otros....

//**************************************************************************
// constructor de la escena (no puede usar ordenes de OpenGL)
//**************************************************************************
Escena::Escena()
{
   Front_plane = 50.0;
   Back_plane = 2000.0;
   Observer_distance = 4 * Front_plane;
   Observer_angle_x = 0.0;
   Observer_angle_y = 0.0;

   ejes.changeAxisSize(5000);

   // crear los objetos de la escena....
   // .......completar: ...
   // .....
   visu.resize(4);
   visu[0] = false;
   visu[1] = false;
   visu[2] = true;
   visu[3] = false;
   cubo = new Cubo(50);
   tetraedro = new Tetraedro(50);
   peon = new ObjRevolucion("plys/peon.ply", 10, tapa_sup, tapa_inf, 'y');
   cono = new Cono(10, 10, 70, 30, tapa_sup, tapa_inf);
   cilindro = new Cilindro(100, 100, 70, 30, tapa_sup, tapa_inf);
   beethoven = new ObjPLY("plys/beethoven.ply");
   esfera = new Esfera(100, 100, 30, tapa_sup, tapa_inf);

}

//**************************************************************************
// inicialización de la escena (se ejecuta cuando ya se ha creado la ventana, por
// tanto sí puede ejecutar ordenes de OpenGL)
// Principalmemnte, inicializa OpenGL y la transf. de vista y proyección
//**************************************************************************

void Escena::inicializar(int UI_window_width, int UI_window_height)
{
   glClearColor(1.0, 1.0, 1.0, 1.0); // se indica cual sera el color para limpiar la ventana	(r,v,a,al)

   glEnable(GL_DEPTH_TEST); // se habilita el z-bufer

   Width = UI_window_width / 10;
   Height = UI_window_height / 10;

   change_projection(float(UI_window_width) / float(UI_window_height));
   glViewport(0, 0, UI_window_width, UI_window_height);
}

// **************************************************************************
//
// función de dibujo de la escena: limpia ventana, fija cámara, dibuja ejes,
// y dibuja los objetos
//
// **************************************************************************

//colocar cada objeto en un sitio distinto
void Escena::dibujar()
{

   glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); // Limpiar la pantalla
   change_observer();
   ejes.draw();
   // COMPLETAR
   //   Dibujar los diferentes elementos de la escena
   // Habrá que tener en esta primera práctica una variable que indique qué objeto se ha de visualizar
   // y hacer
   //cubo.draw()
   // o
   // tetraedro.draw()

   if (Bcubo && cubo != nullptr)
   {
      glPushMatrix();
      glTranslatef(0, 0, 0);
      cubo->draw(modo, visu);
      glPopMatrix();
   }

   if (Btetraedro && tetraedro != nullptr)
   {
      glPushMatrix();
      glTranslatef(-50, 0, 0);
      tetraedro->draw(modo, visu);
      glPopMatrix();
   }

   if (Brev && peon != nullptr)
   {
      glPushMatrix();
      glTranslatef(-100, 0, 0);
      glScalef(10,10,10);
      peon->draw(modo, visu);
      glPopMatrix();
   }
   if (Bcilindro && cilindro != nullptr)
   {
      glPushMatrix();
      glTranslatef(-70, 0, 100);
      cilindro->draw(modo, visu);
      glPopMatrix();
   }

   if (Bcono && cono != nullptr)
   {
      glPushMatrix();
      glTranslatef(-100, 0, -100);
      cono->draw(modo, visu);
      glPopMatrix();
   }

   if (Besfera && esfera != nullptr)
   {
      glPushMatrix();
      glTranslatef(100, 0, 50);
      esfera->draw(modo, visu);
      glPopMatrix();
   }
   if (Bply && beethoven != nullptr)
   {
      glPushMatrix();
      glTranslatef(100, 0, -50);
      glScalef(10,10,10);
      beethoven->draw(modo, visu);
      glPopMatrix();
   }
}

//**************************************************************************
//
// función que se invoca cuando se pulsa una tecla
// Devuelve true si se ha pulsado la tecla para terminar el programa (Q),
// devuelve false en otro caso.
//
//**************************************************************************

bool Escena::teclaPulsada(unsigned char tecla, int x, int y)
{
   using namespace std;
   cout << "Tecla pulsada: '" << tecla << "'" << endl;
   bool salir = false;
   switch (toupper(tecla))
   {
   case 'Q':
      if (modoMenu != NADA)
         modoMenu = NADA;
      else
      {
         salir = true;
      }
      break;
   case 'H':
      if (modoMenu == NADA){
         if (tapa_inf){
            cout << "\nQuitando Tapa inferior" << endl;
            tapa_inf=false;
            esfera->ModificarTapas(tapa_sup, tapa_inf);
            peon->ModificarTapas(tapa_sup, tapa_inf);
            cono->ModificarTapas(tapa_sup, tapa_inf);
            cilindro->ModificarTapas(tapa_sup, tapa_inf);
         } else{
            tapa_inf = true;
            esfera->ModificarTapas(tapa_sup, tapa_inf);
            peon->ModificarTapas(tapa_sup, tapa_inf);
            cono->ModificarTapas(tapa_sup, tapa_inf);
            cilindro->ModificarTapas(tapa_sup, tapa_inf);
         }
      }
      break;
   case 'G':
      if (modoMenu == NADA){
         if (tapa_sup){
            cout << "\nQuitando Tapa Superior" << endl;
            tapa_sup=false;
            esfera->ModificarTapas(tapa_sup, tapa_inf);
            peon->ModificarTapas(tapa_sup, tapa_inf);
            cono->ModificarTapas(tapa_sup, tapa_inf);
            cilindro->ModificarTapas(tapa_sup, tapa_inf);
         } else{
            tapa_sup = true;
            esfera->ModificarTapas(tapa_sup, tapa_inf);
            peon->ModificarTapas(tapa_sup, tapa_inf);
            cono->ModificarTapas(tapa_sup, tapa_inf);
            cilindro->ModificarTapas(tapa_sup, tapa_inf);
         }
      }
      break;
   case 'O':
      // ENTRAMOS EN MODO SELECCION DE OBJETO
      if (modoMenu == NADA)
      {
         cout << "Menu seleccion de objeto" << endl;
         cout << "Mostrar/ocultar cubo: C" << endl;
         cout << "Mostrar/ocultar tetraedro: T" << endl;
         cout << "Mostrar/ocultar cilindro: R" << endl;
         cout << "Mostrar/ocultar esfera: W" << endl;
         cout << "Mostrar/ocultar cono: E" << endl;
         cout << "Mostrar/ocultar archivos ply: Z" << endl;
         cout << "Mostrar/ocultar objeto de revolucion de archivo ply: K" << endl;
         modoMenu = SELOBJETO;
      }
      else
      {
         cout << "Opcion no valida!\n";
      }
      break;

   case 'V':
      // ENTRAMOS EN MODO SELECCION DE MODO DE VISUALIZACION
      if (modoMenu == NADA)
      {
         cout << "Menu seleccion de modo de visualizacion" << endl;
         cout << "Activar/desactivar visualización en modo puntos: P" << endl;
         cout << "Activar/desactivar visualización en modo lineas: L" << endl;
         cout << "Activar/desactivar visualización en modo solido: S" << endl;
         cout << "Activar/desactivar visualización en modo ajedrez: A" << endl;
         modoMenu = SELVISUALIZACION;
      }
      else
      {
         cout << "Opcion no valida!\n";
      }

   case 'D':
      // ENTRAMOS EN MODO SELECCION DE DIBUJADO
      if (modoMenu == NADA)
      {
         cout << "Menu seleccion de modo de dibujado" << endl;
         cout << "1: Activar dibujado con glDrawElements" << endl;
         cout << "2: Activar dibujado con Vertex Buffer Objects" << endl;
         modoMenu = SELDIBUJADO;
      }
      else
      {
         cout << "Opcion no valida!\n";
      }
      break;

   //MODO SELECCION OBJETO
   case 'K':
      if (modoMenu == SELOBJETO)
      {
         if (Brev)
         {
            Brev = false;
         }
         else
         {
            Brev = true;
            cout << "Pintando ObjRevolucion\n";
         }
      }
      else
         cout << "Opcion no valida!\n";
      break;

   case 'C':
      if (modoMenu == SELOBJETO)
      {
         if (Bcubo)
         {
            Bcubo = false;
         }
         else
         {
            Bcubo = true;
            cout << "Pintando cubo\n";
         }
      }
      else
         cout << "Opcion no valida!\n";
      break;

   case 'T':
      if (modoMenu == SELOBJETO)
      {
         if (Btetraedro)
         {
            Btetraedro = false;
         }
         else
         {
            Btetraedro = true;
            cout << "Pintando tetraedro\n";
         }
      }
      else
      {
         cout << "Opcion no valida!\n";
      }
      break;
   case 'R':
      if (modoMenu == SELOBJETO)
      {
         if (Bcilindro)
            Bcilindro = false;
         else
         {
            Bcilindro = true;
            cout << "Pintando Cilindro\n";
         }
      }
      else
         cout << "Opcion no valida!\n";
      break;

   case 'E':
      if (modoMenu == SELOBJETO)
      {
         if (Bcono)
            Bcono = false;
         else
         {
            Bcono = true;
            cout << "Pintando Cono\n";
         }
      }
      else
         cout << "Opcion no valida!\n";
      break;

      case 'Z':
      if (modoMenu == SELOBJETO)
      {
         if (Bply)
            Bply = false;
         else
         {
            Bply = true;
            cout << "Pintando PLY\n";
         }
      }
      else
         cout << "Opcion no valida!\n";

      break;

      case 'W':
      if (modoMenu == SELOBJETO)
      {
         if (Besfera)
            Besfera = false;
         else
         {
            Besfera = true;
            cout << "Pintando Esfera\n";
         }
      }
      else
         cout << "Opcion no valida!\n";
      break;

   //MODO SELECCION MODO DE VISUALIZACION
   case 'P':
      if (modoMenu == SELVISUALIZACION)
      {
         if (visu[0])
         {
            visu[0] = false;
         }
         else
         {
            cout << "Modo Puntos elegido\n";
            visu[0] = true;
         }
      }
      else
         cout << "Opcion no valida!\n";
      break;
   
   case 'L':
      if (modoMenu == SELVISUALIZACION)
      {
         if (visu[1])
            visu[1] = false;
         else
         {
            cout << "Modo Lineas elegido\n";
            visu[1] = true;
         }
      }
      else
         cout << "Opcion no valida!\n";
      break;
   
   case 'S':
      if (modoMenu == SELVISUALIZACION)
      {
         if (visu[2])
            visu[2] = false;
         else
         {
            cout << "Modo Solido elegido\n";
            visu[2] = true;
         }
      }
      else
         cout << "Opcion no valida!\n";

      break;

   case 'A':
      if (modoMenu == SELVISUALIZACION)
      {
         if (visu[3])
            visu[3] = false;
         else
         {
            cout << "Modo Ajedrez elegido\n";
            visu[3] = true;
         }
      }
      else
         cout << "Opcion no valida!\n";
      break;

   //MODO SELECCION DE DIBUJADO
   case '1':
      if (modoMenu == SELDIBUJADO)
      {
         cout << "Modo Inmediato elegido\n";
         modo = INMEDIATO;
      }
      else
         cout << "Opcion no valida!\n";
      break;

   case '2':
      if (modoMenu == SELDIBUJADO)
      {
         cout << "Modo Diferido elegido\n";
         modo = DIFERIDO;
      }
      else
         cout << "Opcion no valida!\n";
      break;
   }
   return salir;
}
//**************************************************************************

void Escena::teclaEspecial(int Tecla1, int x, int y)
{
   switch (Tecla1)
   {
   case GLUT_KEY_LEFT:
      Observer_angle_y--;
      break;
   case GLUT_KEY_RIGHT:
      Observer_angle_y++;
      break;
   case GLUT_KEY_UP:
      Observer_angle_x--;
      break;
   case GLUT_KEY_DOWN:
      Observer_angle_x++;
      break;
   case GLUT_KEY_F1: //He cambiado las teclas porque no las tengo en mi teclado
      Observer_distance *= 1.2;
      break;
   case GLUT_KEY_F2: // He cambiado las teclas porque no las tengo en mi teclado
      Observer_distance /= 1.2;
      break;
   }

   //std::cout << Observer_distance << std::endl;
}

//**************************************************************************
// Funcion para definir la transformación de proyeccion
//
// ratio_xy : relacción de aspecto del viewport ( == ancho(X) / alto(Y) )
//
//***************************************************************************

void Escena::change_projection(const float ratio_xy)
{
   glMatrixMode(GL_PROJECTION);
   glLoadIdentity();
   const float wx = float(Height) * ratio_xy;
   glFrustum(-wx, wx, -Height, Height, Front_plane, Back_plane);
}
//**************************************************************************
// Funcion que se invoca cuando cambia el tamaño de la ventana
//***************************************************************************

void Escena::redimensionar(int newWidth, int newHeight)
{
   Width = newWidth / 10;
   Height = newHeight / 10;
   change_projection(float(newHeight) / float(newWidth));
   glViewport(0, 0, newWidth, newHeight);
}

//**************************************************************************
// Funcion para definir la transformación de vista (posicionar la camara)
//***************************************************************************

void Escena::change_observer()
{
   // posicion del observador
   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();
   glTranslatef(0.0, 0.0, -Observer_distance);
   glRotatef(Observer_angle_y, 0.0, 1.0, 0.0);
   glRotatef(Observer_angle_x, 1.0, 0.0, 0.0);
}
